public class Main {
    public static void main(String[] args) {
        String[] words = {"pippo", "pluto", "alice", "bob"};

        for (String word : words) {
            String middleChar;
         /* TODO */
            System.out.println(middleChar);
        }
    }
}