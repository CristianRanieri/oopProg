package it.unisa.railways;

import java.util.List;

public class ExpressTrain {
    /* TODO */

}
