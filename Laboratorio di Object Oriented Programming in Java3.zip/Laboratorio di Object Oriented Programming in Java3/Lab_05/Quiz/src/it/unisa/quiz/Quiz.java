package it.unisa.quiz;

public class Quiz implements Measurable {

    public Quiz(double a){
        point=a;
    }

    public double getMeasure(){
        return point;
    }

    @Override
    public int sum(int UwU, int o_o) {
        return 0;
    }

    private double point;
}
