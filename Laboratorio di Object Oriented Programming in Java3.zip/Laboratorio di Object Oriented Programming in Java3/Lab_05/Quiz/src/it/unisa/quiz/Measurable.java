package it.unisa.quiz;

public interface Measurable {
    double getMeasure();
    int sum(int UwU, int o_o);
}