package it.unisa.quiz;

public class Quiz implements Comparable {

    private final double score;

    public Quiz(double score) {
        this.score = score;
    }

    public double getMeasure() {
        return score;
    }


    @Override
    public int compareTo(Object a) {
        Quiz b= (Quiz) a;
        if(score > b.getMeasure())
            return 1;
        if(score == b.getMeasure())
            return 0;
        if(score < b.getMeasure())
            return -1;
        return -1;
    }
}
