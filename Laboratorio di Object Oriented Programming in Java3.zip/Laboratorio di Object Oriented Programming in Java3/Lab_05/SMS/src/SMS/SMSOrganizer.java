package SMS;
import java.util.*;
public class SMSOrganizer {
    final private List<SMS> messages;
    public static final Comparator<SMS> cmpDate = new Comparator<>(){
        @Override
        public int compare(SMS o1, SMS o2) {
            return o1.getDate().compareTo(o2.getDate());
        }
    };
    public static Comparator<SMS> cmpSender = new Comparator<SMS>() {
        @Override
        public int compare(SMS o1, SMS o2) {
            return o1.getSender().compareTo(o2.getSender());
        }
    };
    public SMSOrganizer() {
        messages = new ArrayList<>();
    }

    public void addSMSToOrganizer(SMS sms) {
        this.messages.add(sms);
    }

    public List<SMS> getListByDate() {
        messages.sort(cmpDate);
        return this.messages;
    }
    public List<SMS> getListBySender() {
        messages.sort(cmpSender);
        return this.messages;
    }
}
