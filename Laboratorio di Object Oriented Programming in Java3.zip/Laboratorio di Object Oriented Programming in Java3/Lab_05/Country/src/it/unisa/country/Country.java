package it.unisa.country;

public class Country implements Comparable {

    final private String name;
    final private double surfaceArea;

    public Country(String name, double surfaceArea) {
        this.name = name;
        this.surfaceArea = surfaceArea;
    }

    public String getName() {
        return name;
    }

    public double getSurfaceArea() {
        return surfaceArea;
    }


    @Override
    public int compareTo(Object o) {
        if(surfaceArea > ((Country) o).surfaceArea)
            return 1;
        if(surfaceArea == ((Country) o).surfaceArea)
            return 0;
        if(surfaceArea < ((Country) o).surfaceArea)
            return -1;
        return -1;
    }
}