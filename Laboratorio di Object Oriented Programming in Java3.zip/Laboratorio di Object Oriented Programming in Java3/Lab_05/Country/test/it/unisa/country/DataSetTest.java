package it.unisa.country;

import org.junit.Assert;
import org.junit.Test;

public class DataSetTest {
    @Test
    public void testMinimum() {
        Country a= new Country("a",10);
        Country b= new Country("a",20);
        Country c= new Country("a",30);
        DataSet dataSet = new DataSet();
        dataSet.add(a);
        dataSet.add(b);
        dataSet.add(c);
        Assert.assertEquals(10,dataSet.getMinimum().getSurfaceArea(),0);
    }

    @Test
    public void testMaximum() {
        Country a= new Country("a",10);
        Country b= new Country("a",20);
        Country c= new Country("a",30);
        DataSet dataSet = new DataSet();
        dataSet.add(a);
        dataSet.add(b);
        dataSet.add(c);
        Assert.assertEquals(30,dataSet.getMaximum().getSurfaceArea(),0);
    }
}