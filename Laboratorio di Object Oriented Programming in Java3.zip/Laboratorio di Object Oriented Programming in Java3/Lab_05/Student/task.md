# Studente

Progettare una classe `Student` che implementi l’interfaccia `Comparable`.
Gli studenti vanno confrontate sulla base del loro cognome.
Testare la classe verificando che data una lista di cinque oggetti `Student` siano restituiti i cognomi del primo e
dell’ultimo studente.