import java.awt.*;

public class Main {
    public static void main(String[] args) {
        int x = 0;
        int y = 0;
        int width = 10;
        int height = 20;

        int newX = 5;
        int newY = 5;

        double area;
        double perimeter;

        /* TODO */

        System.out.println(box);
        System.out.println(area);
        System.out.println(perimeter);

    }
}