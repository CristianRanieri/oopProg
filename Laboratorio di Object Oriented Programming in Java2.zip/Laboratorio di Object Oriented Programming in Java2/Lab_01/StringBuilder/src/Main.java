public class Main {
    public static void main(String[] args) {
        String sentence = "Hello, World!";
        StringBuilder newSentence = new StringBuilder();
      /* TODO */

        System.out.println(newSentence);
    }
}