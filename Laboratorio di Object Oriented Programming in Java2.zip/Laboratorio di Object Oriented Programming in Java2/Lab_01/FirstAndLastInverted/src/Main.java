public class Main {
    public static void main(String[] args) {
        String[] words = {"c", "ac", "pippo"};

        for (String word : words) {
            String result;

            /* TODO */

            System.out.println(result);
        }
    }
}