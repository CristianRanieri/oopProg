# Prima e ultima parola

Realizzare e testare una classe `FirstAndLastWord` che contenga due metodi.

Il primo metodo chiede all’utente quante parole voglia inserire, le prenda in input da tastiera e stampi la prima e
l’ultima parola secondo l’ordine alfabetico.

Il secondo metodo è uguale al precedente ma ignora la differenza tra maiuscole e minuscole