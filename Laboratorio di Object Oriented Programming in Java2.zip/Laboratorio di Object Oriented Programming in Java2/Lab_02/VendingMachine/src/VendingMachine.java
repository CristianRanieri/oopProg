public class VendingMachine {
    private int numberOfCans;
    private int numberOfTokens;

    public VendingMachine() {
    }

    public VendingMachine(int initialNumberOfCans) {
        numberOfCans = initialNumberOfCans;
        numberOfTokens = 0;
    }

    public void addCans(int numberOfNewCans) {
        /* TODO */
    }

    public void takeCan() {
        /* TODO */
    }

    public void takeTokens() {
        /* TODO */
    }

    public int getNumberOfCans() {
        /* TODO */
    }

    public int getNumberOfTokens() {
        /* TODO */
    }
}