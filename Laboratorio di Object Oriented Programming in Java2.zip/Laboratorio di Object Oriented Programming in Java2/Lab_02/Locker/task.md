# Serratura

Realizzare e testare una classe `Locker` per rappresentare una serratura con combinazione di tre lettere maiuscole
I metodi sono

* void `unlock(String)` che apre la serratura se il codice passato è quello della serratura
* boolean `isOpen()` che verifica se la serratura è aperta
* void `lock()` che chiude la serratura
* void `newComb(String)` che setta una nuova combinazione se la serratura è aperta