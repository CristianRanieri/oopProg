public class Car {
    private double gas;
    private final double consumptionRate;

    /* TODO */

    public double getGas() {
        /* TODO */
    }

    public void addGas(double gas) {
        /* TODO */
    }

    public void drive(double km) {
        /* TODO */
    }
}