public class Infected {

    private final String disease;
    private int numberOfInfected;

    public Infected(String disease) {
        /* TODO */
    }

    public Infected(String disease, int numberOfInfected) {/* TODO */
    }

    public int getNumberOfInfected() {
        /* TODO */
    }

    public String getDisease() {
        return disease;
    }

    public void addInfected(int numberOfInfected) {
        /* TODO */
    }

    public void updateInfectedByRt(double Rt) {
        /* TODO */
    }
}