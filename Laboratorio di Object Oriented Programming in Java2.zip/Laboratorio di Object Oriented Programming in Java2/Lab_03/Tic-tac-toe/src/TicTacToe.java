import java.util.Scanner;

public class TicTacToe {

    private final String[][] board;
    static int ROWS = 3;
    static int COLUMNS = 3;
    static String player1 = "x";
    static String player2 = "o";

    public TicTacToe() {
        board = new String[ROWS][COLUMNS];
        for (int i = 0; i < ROWS; i++)
            for (int j = 0; j < COLUMNS; j++)
                board[i][j] = " ";
    }

    public String toString() {
        StringBuilder r = new StringBuilder();
        for (int i = 0; i < ROWS; i++) {
            r.append("|");
            for (int j = 0; j < COLUMNS; j++)
                r.append(board[i][j]);
            r.append("|\n");
        }
        return r.toString();
    }

    public void set(int i, int j, String player) {
        if (board[i][j].equals(" "))
            board[i][j] = player;
    }

    public String getWinner() {
        int sem1, sem2, sem3, sem4, sem5, sem6, sem7, sem8;
        for (int i = 0; i < ROWS; i++) {
            sem1 = 0;
            sem2 = 0;
            sem3 = 0;
            sem4 = 0;
            sem5 = 0;
            sem6 = 0;
            sem7 = 0;
            sem8 = 0;
            for (int j = 0; j < COLUMNS; j++) {
                if (board[i][j].equals(player1))
                    sem1++;
                else if(!board[i][j].equals(" "))
                    sem2++;

                if (board[j][i].equals(player1))
                    sem3++;
                else if(!board[j][i].equals(" "))
                    sem4++;

                if (board[j][j].equals(player1))
                    sem5++;
                else if(!board[j][j].equals(" "))
                    sem6++;

                if (board[ROWS - (j+1)][ROWS - (j+1)].equals(player1))
                    sem7++;
                else if(!board[ROWS - (j+1)][ROWS - (j+1)].equals(" "))
                    sem8++;
            }
            if (sem1 == ROWS)
                return player1;
            else if (sem2 == ROWS)
                return player2;

            if (sem3 == ROWS)
                return player1;
            else if (sem4 == ROWS)
                return player2;

            if (sem5 == ROWS)
                return player1;
            else if (sem6 == ROWS)
                return player2;

            if (sem7 == ROWS)
                return player1;
            else if (sem8 == ROWS)
                return player2;

        }
        return "Nessun vincitore";
    }

    public static void main(String[] args) {
        String player = player1;
        TicTacToe game = new TicTacToe();
        Scanner in = new Scanner(System.in);
        int row, column;
        System.out.println(game);

        do {
System.out.println(game.getWinner());
            if (game.getWinner().equals(player1) || game.getWinner().equals(player2)) {
                System.out.println("Partita finita");
                System.exit(0);
            }

            System.out.println("Inserisci riga per " + player + " (-1 per uscire):");
            row = in.nextInt();

            if (row == -1) {
                System.out.println("Partita finita");
                System.exit(0);
            }

            System.out.println("Inserisci colonna per " + player + ":");
            column = in.nextInt();

            if (row >= ROWS || column >= COLUMNS) {
                System.out.println("Combinazione non valida");
            } else {
                game.set(row,column,player);
                if(player==player1)
                    player=player2;
                else
                    player=player1;
            }

        } while (row < ROWS && column < COLUMNS);
    }
}
