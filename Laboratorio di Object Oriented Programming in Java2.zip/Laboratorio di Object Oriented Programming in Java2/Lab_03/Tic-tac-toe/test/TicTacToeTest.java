import org.junit.Assert;
import org.junit.Test;

public class TicTacToeTest {

    @Test
    public void horizontalWinTest() {
        TicTacToe t = new TicTacToe();
        t.set(0,0,TicTacToe.player1);
        t.set(0,1,TicTacToe.player1);
        t.set(0,2,TicTacToe.player1);
        System.out.println(t.getWinner());
        Assert.assertEquals(true,t.getWinner().equals(TicTacToe.player1));
    }

    @Test
    public void verticalWinTest() {
        TicTacToe t = new TicTacToe();
        t.set(0,0,TicTacToe.player1);
        t.set(1,0,TicTacToe.player1);
        t.set(2,0,TicTacToe.player1);
        System.out.println(t.getWinner());
        Assert.assertEquals(true,t.getWinner().equals(TicTacToe.player1));
    }

    @Test
    public void firstDiagonalWinTest() {
        TicTacToe t = new TicTacToe();
        t.set(0,0,TicTacToe.player1);
        t.set(1,1,TicTacToe.player1);
        t.set(2,2,TicTacToe.player1);
        System.out.println(t.getWinner());
        Assert.assertEquals(true,t.getWinner().equals(TicTacToe.player1));
    }

    @Test
    public void secondDiagonalWinTest() {
        TicTacToe t = new TicTacToe();
        t.set(2,2,TicTacToe.player1);
        t.set(1,1,TicTacToe.player1);
        t.set(0,0,TicTacToe.player1);
        System.out.println(t.getWinner());
        Assert.assertEquals(true,t.getWinner().equals(TicTacToe.player1));
    }
}