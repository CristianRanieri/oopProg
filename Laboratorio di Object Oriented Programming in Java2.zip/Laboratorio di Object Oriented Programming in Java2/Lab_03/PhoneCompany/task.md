# Compagnia telefonica

Una compagnia telefonica memorizza i consumi trimestrali dei propri utenti in un file organizzato come segue:

- Codice dell’utente;
- Nome dell’utente;
- Cognome dell’utente;
- Numero di minuti consumati;
- Numero di sms inviati;
- Numero di MB consumati.

Progettare e realizzare un programma per la fatturazione trimestrale, supponendo che i costi per minuti, sms e GB
siano stabiliti trimestre per trimestre.