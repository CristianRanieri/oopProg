import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PhoneCompany {
    List<User> users;

    private final double minutePrice=0.1;
    private final double smsPrice=0.05;
    private final double gbPrice=2;

    private List<User> l;


    public PhoneCompany(double d,double e,int f){
        l= new ArrayList<>();
    }
    public void readUserDataFromFile(File file) throws FileNotFoundException {
        Scanner in = new Scanner(file);
        while(in.hasNext()) {
            int a = in.nextInt();
            in.nextLine();
            String b = in.nextLine();
            String c = in.nextLine();
            User u = new User(a, b, c);

            u.setUsedMinutes(in.nextInt());
            in.nextLine();
            u.setUsedSMS(in.nextInt());
            in.nextLine();
            u.setUsedMB(in.nextDouble());
            if(in.hasNext())
                in.nextLine();

            l.add(u);
        }
    }

    public User findUserByCode(int n){
        for(User u : l)
            if(n==u.getCode())
                return u;

        return null;
    }

    public void computeUserCost(User u){;
        u.setTotalCost(u.getUsedMinutes()*minutePrice+u.getUsedMB()*gbPrice/1000 + u.getUsedSMS()*smsPrice);
    }
}
