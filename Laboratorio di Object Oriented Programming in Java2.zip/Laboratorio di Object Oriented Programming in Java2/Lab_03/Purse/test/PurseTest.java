import org.junit.Assert;
import org.junit.Test;

public class PurseTest {

  @Test
  public void findTest() {
    Purse a = new Purse();
    a.add(new Coin("Dollar", 1));
    a.add(new Coin("Dime", 1));
    boolean c = a.find(new Coin("Dollar", 1));
    System.out.println("qui");
    Assert.assertEquals(true,c);
  }

  @Test
  public void countTest() {
    Purse a = new Purse();
    a.add(new Coin("Dollar", 1));
    a.add(new Coin("Dollar", 1));
    int c = a.count(new Coin("Dollar", 1));
    System.out.println("qui 1 "+c);
    Assert.assertEquals(2, c);
  }

  @Test
  public void minMaxTest() {
    Purse a = new Purse();
    a.add(new Coin("Dollar", 1));
    a.add(new Coin("Dime", 0.10));
    Coin c = a.getMaximum();

    boolean l = c.equals(new Coin("Dollar", 1));
    System.out.println("qui "+l);
    Assert.assertEquals(true,l);
  }

  @Test
  public void getTotalTest() {
    Purse a = new Purse();
    a.add(new Coin("Dollar", 1));
    a.add(new Coin("Dime", 0.10));
    double c = a.getTotal();
    System.out.println("qui 4 "+c);
    Assert.assertEquals(1.1,c,0);
  }

  @Test
  public void addRemoveTest() {
    Purse a = new Purse();
    a.add(new Coin("Dollar", 1));
    a.add(new Coin("Dime", 0.10));
    a.remove(new Coin("Dime", 0.10));
    double c = a.getTotal();
    System.out.println("qui 3 "+ c);
    Assert.assertEquals(1.0,c,0);
  }

  @Test
  public void hasCoinTest() {
    Purse a = new Purse();
    a.add(new Coin("Dollar", 1));
    a.add(new Coin("Dime", 0.5));
    boolean c = a.hasCoin(new Coin("Dollar", 1));
    System.out.println("qui 2 "+c);
    Assert.assertEquals(true, c);
  }

  @Test
  public void toStringTest() {
    Purse a = new Purse();
    a.add(new Coin("Dollar", 1));
    a.add(new Coin("Dime", 0.10));
    System.out.println("qui");
    Assert.assertEquals("Purse[Dollar = 1, Quarter = 0, Dime = 1, Nickel = 0, Cent = 0]", a.toString());
  }

  @Test
  public void equalsTest() {
    Purse a = new Purse();
    a.add(new Coin("Dollar",1));
    a.add(new Coin("Quarter",0.5));

    Purse b = new Purse();
    b.add(new Coin("Dollar",1));
    b.add(new Coin("Dime",0.10));
    System.out.println("qui 5");
    Assert.assertEquals(false,a.equals(b));
  }
}

