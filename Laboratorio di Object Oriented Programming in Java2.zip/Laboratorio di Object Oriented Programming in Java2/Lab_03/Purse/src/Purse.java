import java.util.ArrayList;
import java.util.List;

public class Purse {

    /* TODO */

    private final List<Coin> coins;

    public Purse() {
        coins = new ArrayList<>();
    }

    public void add(Coin coin) {
        coins.add(coin);
    }

    public boolean find(Coin coin) {
        for(Coin a : coins)
            if(a.equals(coin))
                return true;

        return false;
    }

    public int count(Coin coin) {
        int count=0;
        for(Coin a : coins)
            if(a.equals(coin))
                count++;

        return count;
    }

    public Coin getMinimum() {
        Coin min=coins.get(0);
        for(int i=1;i<coins.size();i++)
            if(coins.get(i).getValue()<min.getValue())
                min=coins.get(i);
        return min;
    }

    public Coin getMaximum() {
        Coin max=coins.get(0);
        for(int i=1;i<coins.size();i++)
            if(coins.get(i).getValue()>max.getValue())
                max=coins.get(i);
        return max;
    }

    public double getTotal() {
        double cont=0;
        for(Coin a : coins)
            cont+=a.getValue();

        return cont;
    }

    public void remove(Coin coin) {
        for(Coin a : coins)
            if(a.equals(coin))
                coins.remove(a);
    }

    public boolean hasCoin(Coin coin) {
        int c=0;
        for(Coin a : coins)
            if(a.equals(coin))
                c++;
        if(c==1)
            return true;
        else
            return false;
    }

    @Override
    public String toString() {
        String s;
        int d=0,q=0,d2=0,n=0,c2=0;

        for(Coin c : coins){
            if(c.equals(new Coin("Dollar",1)))
                d++;
            if(c.equals(new Coin("Quarter",0.25)))
                q++;
            if(c.equals(new Coin("Dime",0.10)))
                d2++;
            if(c.equals(new Coin("Nickel",0.05)))
                n++;
            if(c.equals(new Coin("Cent",0.01)))
                c2++;
        }
        s="Purse[Dollar = "+d+", Quarter = "+q+", Dime = "+d2+", Nickel = "+n+", Cent = "+c2+"]";
    System.out.println(s);
        return s;
    }

    @Override
    public boolean equals(Object o) {
        System.out.println(coins.toString()+"  "+o.toString());
        if((coins.toString()).equals(o.toString()))
            return true;
        return false;
    }
}