import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CarSeller {
    private final List<Car> cars;

    public CarSeller() {
        this.cars = new ArrayList<>();
    }

    public void readCarFile(File file) throws FileNotFoundException {
        Scanner in= new Scanner(file);
        String a,b;
        int c,d;
        while(in.hasNext()){
                a=in.nextLine();
                b=in.nextLine();
                c=in.nextInt();
                in.nextLine();
                d=in.nextInt();
                if(in.hasNext())
                    in.nextLine();
            cars.add(new Car(a,b,c,d));
        }
    }

    public Car findCar(String a,String b){
        for(Car c : cars){
            if(c.getBrand().equals(a) && c.getModel().equals(b))
                return c;
        }
        return null;
    }

    public Car findCarYear(String a,String b,int y){
        for(Car c : cars){
            if(c.getBrand().equals(a) && c.getModel().equals(b) && c.getManufacturingYear()>y)
                return c;
        }
        return null;
    }

    public Car findCarCost(String a,String b,int d){
        for(Car c : cars){
            if(c.getBrand().equals(a) && c.getModel().equals(b) && c.getPrice()<d)
                return c;
        }
        return null;
    }

}