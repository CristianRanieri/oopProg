import org.junit.Assert;
import org.junit.Test;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Path;
import java.util.List;

public class CarSellerTest {
    @Test
    public void test() throws FileNotFoundException {
        File file = Path.of("test/").resolve("testData.txt").toFile();;
        CarSeller cs= new CarSeller();
        cs.readCarFile(file);
        Car c=cs.findCar("Tesla","Model Y");
        System.out.println(c);
        Assert.assertEquals(true,c!=null);

        c=cs.findCarYear("Tesla","Model Y",2018);
        Assert.assertEquals(true,c!=null);

        c=cs.findCarCost("Tesla","Model Y",40000);
        Assert.assertEquals(true,c!=null);
    }
}