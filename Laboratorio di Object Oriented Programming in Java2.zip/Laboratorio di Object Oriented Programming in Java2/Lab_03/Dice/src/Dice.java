import java.util.Random;
import java.util.Scanner;

public class Dice {

    public static void main(String[] args) {
        BankAccount playerAccount = new BankAccount(1000);
        BankAccount casinoAccount = new BankAccount(100000);
        int predictedValue, actualValue;
        double bet;
        String choice = "no";
        Scanner in = new Scanner(System.in);
        Random a= new Random();
        int n;
        String sem="si";

        while(sem.equals("si")) {
            sem="no";
            n = in.nextInt();
            in.nextLine();
            bet = in.nextDouble();
            if (n == (a.nextInt(5)+1))
            {
                if (playerAccount.getBalance() <= bet)
                {
                    playerAccount.deposit(bet * 5);
                    casinoAccount.deposit(bet * (-5));
                }
            }
            else
            {
                playerAccount.deposit(bet * (-1));
                casinoAccount.deposit((bet));
            }

            if(playerAccount.getBalance()==0)
                System.out.println("il saldo e finito");
            else {
                System.out.println("inserisci si se vuoi conntinuare");
                sem=in.nextLine();
            }
        }
            System.out.println("Il tuo saldo è " + playerAccount.getBalance());
    }
}