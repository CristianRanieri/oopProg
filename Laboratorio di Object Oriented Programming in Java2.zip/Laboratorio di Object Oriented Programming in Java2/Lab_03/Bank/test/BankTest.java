import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class BankTest {

    @Before
    public void setup(){
        BankAccount.totalNumberOfAccounts = 0;
    }

    @Test
    public void findAccountTest() {
        Bank b = new Bank();
        b.addAccount(1000, "Dario");
        BankAccount newAccount = b.find(1);
        Assert.assertEquals(1, newAccount.getAccountNumber());
        Assert.assertEquals(1000, newAccount.getBalance(), 0);
        Assert.assertEquals("Dario", newAccount.getCustomerName());
    }

    @Test
    public void depositTest() {
        Bank b= new Bank();
        b.addAccount(1000,"CTR");
        b.addAccount(1000,"CTl");
        b.addAccount(1000,"CTf");
        b.deposit(1,500);
        Assert.assertEquals(b.getBalance(1),1500,0);
    }

    @Test
    public void withdrawTest() {
        Bank b= new Bank();
        b.addAccount(1000,"CTR");
        b.addAccount(1000,"CTl");
        b.addAccount(1000,"CTf");
        b.withdraw(1,500);
        Assert.assertEquals(b.getBalance(1),500,0);
    }

    @Test
    public void transferTest() {
        Bank b= new Bank();
        b.addAccount(1000,"CTR");
        b.addAccount(1000,"CTl");
        b.addAccount(1000,"CTf");
        b.transfer(1,2,500);
        Assert.assertEquals(b.getBalance(1),500,0);
    }
}