import java.util.ArrayList;
import java.util.List;

public class Bank {

    private final List<BankAccount> accounts;

    public Bank() {
        this.accounts = new ArrayList<>();
    }

    public void addAccount(double initialBalance, String customerName) {
        accounts.add(new BankAccount(initialBalance,customerName));
    }

    public BankAccount find(int accountNumber) {
        for (BankAccount ba : this.accounts) {
            if (ba.getAccountNumber() == accountNumber)
                return ba;
        }
        return null;
    }

    public void deposit(int accountNumber, double amount) {
        for(BankAccount a : accounts)
            if(a.getAccountNumber()==accountNumber)
                a.deposit(amount);
    }

    public void withdraw(int accountNumber, double amount) {
        for(BankAccount a : accounts)
            if(a.getAccountNumber()==accountNumber)
                a.withdraw(amount);
    }

    public double getBalance(int accountNumber) {
        for(BankAccount a : accounts)
            if(a.getAccountNumber()==accountNumber)
                return a.getBalance();
        return -1;
    }

    public void transfer(int fromAccountNumber, int toAccountNumber, double amount) {
        for(BankAccount a : accounts) {
            if (a.getAccountNumber() == fromAccountNumber)
                a.withdraw(amount);
            if (a.getAccountNumber() == toAccountNumber)
                a.deposit(amount);
        }
    }
}